# Spots

An image sharing.

## Tech Stack

- Html
- css
- Responsive Design

## Deployment

This webpage is Deployed to Github Pages

[Deployment Link](https://jae277.github.io/se_project_spots):z

## A Video About My Project

https://youtu.be/-bSurDJphwc
